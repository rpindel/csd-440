<!--
Robin Pindel
440 mod3 Assignment
8/19/2023

External function file for random number generation.  Function takes two numbers
as parameters, sums them, and returns the value.
-->

<?PHP

function NumSum($num1, $num2) {
  $numSum = $num1 + $num2;

  return $numSum;
}

?>